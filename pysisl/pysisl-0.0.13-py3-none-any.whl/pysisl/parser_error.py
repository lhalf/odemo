# Copyright PA Knowledge Ltd 2021

class ParserError(Exception):
    pass
